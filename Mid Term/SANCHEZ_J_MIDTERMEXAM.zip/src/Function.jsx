import React from "react";

const Function = () =>{
    const[count,setCount] = useState(0);
    return (
        <div>

        </div>
    )
}
export default Function;